/*
 * Ported from http://blobsallad.se/blobsallad.js by Yan Cheng Cheok <yccheok@yahoo.com>
 */

package org.yccheok.blobsallad.demo;

import javax.swing.JApplet;
import org.yccheok.blobsallad.Controller;

/**
 *
 * @author yccheok
 */
public class BlobsalladAppletDemo extends JApplet {

    private Controller controller = null;

    /**
     * Initialization method that will be called after the applet is loaded
     * into the browser.
     */
    @Override
    public void init() {
        // TODO start asynchronous download of heavy resources
        controller = new Controller();

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = controller.getView();

        jPanel2.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel1.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        jLabel1.setText("<html>\nMove around Blob with arrow keys or mouse.\n<br>\nSplit blob with h. \n<br>\nJoin blobs with j. \n<br>\nTurn gravity on / off with g.\n<br>\nOriginal written by (JavaScript version): <a href=\"mailto:bjoern.lindberg@gmail.com\">bjoern.lindberg@gmail.com</a>\n<br>\nPorted over by (Java version): <a href=\"mailto:yccheok@yahoo.com\">yccheok@yahoo.com</a>\n</html>");
        jPanel2.add(jLabel1);

        getContentPane().add(jPanel2, java.awt.BorderLayout.SOUTH);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 579, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 399, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);
    }

    @Override
    public void destroy() {
        controller.stop();
    }

    @Override
    public void stop() {
        controller.stop();
    }

    @Override
    public void start() {
        controller.start();
    }

    public void javaScriptRequestFocus() {
        controller.requestFocus();
    }

    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;

    // TODO overwrite start(), stop() and destroy() methods

}
