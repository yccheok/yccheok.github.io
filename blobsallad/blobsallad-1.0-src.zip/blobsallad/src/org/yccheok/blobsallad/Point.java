/*
 * Ported from http://blobsallad.se/blobsallad.js by Yan Cheng Cheok <yccheok@yahoo.com>
 */

package org.yccheok.blobsallad;

/**
 *
 * @author yccheok
 */
public class Point {
    private final double x;
    private final double y;
    
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * @return the x
     */
    public double getX() {
        return x;
    }

    /**
     * @return the y
     */
    public double getY() {
        return y;
    }
}
